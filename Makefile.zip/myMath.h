
#ifndef _MYMATH_H
#define _MYMATH_H

float add(float x , float y);

float sub(float x , float y);

double mul(double x , int y);

double div(double x, int y);

double Pow(double x , int y);

double Exp(int x);

#endif