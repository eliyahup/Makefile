
#include <stdio.h>
#include "myMath.h"

int main(){
    double x = 0;
printf("enter a real number: ");
scanf("%lf", &x);
double fun1 = sub(add(Exp((int)x),Pow(x,3)),2);
double fun2 = add(mul(3,x),mul(2,Pow(x , 2)));
double fun3 =sub(div(mul(4,Pow(x,3)),5),mul(2,x));
printf("the value of f(x) = e^x+x^3-2 at the point %0.4lf is:\n %0.4lf\n",x, fun1);
printf("the value of f(x) = 3*x+2*x^2 at the point %0.4lf is:\n %0.4lf\n" ,x , fun2);
printf("the value of f(x) = (4*x^3)/5-2x at the point %0.4lf is:\n %0.4lf\n" ,x , fun3);
    return 0;
}