#include "myMath.h"
#define e 2.718281828

double Exp(int x){
    return Pow(e,x);
}
double Pow(double x , int y){
    if(y==0)
    return 1;
     double ans = x;
    for (int i = 1; i < y; i++)
    {
       ans *= x;
    }
    return ans;
}